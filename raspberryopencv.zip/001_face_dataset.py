from flask import Flask, render_template, Response
import cv2
import os
import numpy as np
from PIL import Image
import datetime
import time

app = Flask(__name__)


global quit_flag
quit_flag = False


@app.route("/")
def index():
    return render_template("index.html")


def train_model():
    cam = cv2.VideoCapture(1)
    # cam = cv2.VideoCapture(cv2.CAP_V4L2 + 1)
    cam.set(3, 640)
    cam.set(4, 480)

    print("trainmodel camera open!")
    face_detector = cv2.CascadeClassifier(
        "/home/pi/webapps/opencv/data/haarcascades/haarcascade_frontalface_default.xml"
    )

    # 학습할 데이터셋 경로
    dataset_path = "/home/pi/webapps/practiceproject/dataset"
    traindata_path = "/home/pi/webapps/practiceproject/traindata"
    suffix = datetime.datetime.now().strftime("%y%m%d_%H%M%S")
    # 사람에게 id 부여하기  # 1번은 나임.
    face_id = suffix

    # 폴더 생성?
    # face_folder = os.path.join(dataset_path, f"User.{suffix}")
    # os.makedirs(face_folder, exist_ok=True)
    #

    print("얼굴 정보를 저장합니다. 카메라를 응시하세요...")

    count = 0

    while count < 100:
        ret, frame = cam.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_detector.detectMultiScale(gray, 1.3, 5)

        for x, y, w, h in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            count += 1

            cv2.imwrite(
                os.path.join(dataset_path, f"User.{face_id}.{count}.jpg"),
                gray[y : y + h, x : x + w],
            )

        ret, buffer = cv2.imencode(".jpg", frame)
        frame = buffer.tobytes()
        yield (b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")

    print("얼굴 정보 저장이 완료되었습니다")
    cam.release()
    # cv2.destroyAllWindows()
    print("얼굴 정보를 학습 중입니다\n 잠시만 기다려 주십시오...")

    # training
    def getImageLabels(dataset_path):
        image_paths = [os.path.join(dataset_path, f) for f in os.listdir(dataset_path)]
        face_samples = []
        labels = []

        for image_path in image_paths:
            PIL_img = Image.open(image_path).convert("L")
            img_numpy = np.array(PIL_img, "uint8")
            label = int(os.path.split(image_path)[-1].split(".")[1])
            faces = face_detector.detectMultiScale(img_numpy)

            for x, y, w, h in faces:
                face_samples.append(img_numpy[y : y + h, x : x + w])
                labels.append(label)

        return face_samples, labels

    faces, labels = getImageLabels(dataset_path)

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(labels))

    if not os.path.exists(traindata_path):
        os.makedirs(traindata_path)

    recognizer.save(os.path.join(traindata_path, "traindata.yml"))
    print("얼굴 정보 등록이 완료되었습니다.")


def gen_frames():
    global quit_flag
    quit_flag = False

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read("/home/pi/webapps/practiceproject/traindata/traindata.yml")
    cascadePath = (
        "/home/pi/webapps/opencv/data/haarcascades/haarcascade_frontalface_default.xml"
    )
    faceCascade = cv2.CascadeClassifier(cascadePath)

    font = cv2.FONT_HERSHEY_PLAIN

    cam = cv2.VideoCapture(1)
    # cam = cv2.VideoCapture(cv2.CAP_V4L2 + 1)

    cam.set(3, 640)
    cam.set(4, 480)

    # Define min window size to be recognized as a face
    minW = 0.1 * cam.get(3)
    minH = 0.1 * cam.get(4)

    while True:
        print(quit_flag)
        if quit_flag == True:
            break

        success, frame = cam.read()
        if not success:
            break
        else:
            frame = cv2.flip(frame, 1)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            faces = faceCascade.detectMultiScale(
                gray, scaleFactor=1.2, minNeighbors=5, minSize=(int(minW), int(minH))
            )

            for x, y, w, h in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                id, confidence = recognizer.predict(gray[y : y + h, x : x + w])

                if confidence < 56:
                    id = "Member"
                    confidence = "{0}%".format(round(100 - confidence))
                else:
                    id = "UNKNOWN"
                    confidence = "{0}%".format(round(100 - confidence))

                cv2.putText(frame, str(id), (x + 5, y - 5), font, 1, (0, 255, 255), 1)
                # cv2.putText(
                #   frame, str(confidence), (x + 5, y + h - 5), font, 1, (255, 255, 0), 1
                # )

            # OpenCV 프레임을 바이트 형식으로 인코딩
            ret, buffer = cv2.imencode(".jpg", frame)
            frame = buffer.tobytes()

            # Flask 애플리케이션에서 비디오 프레임을 반환하는 제너레이터
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")

    print("종료")
    cam.release()
    # cv2.destroyAllWindows()
    print("종료")


@app.route("/train", methods=["POST", "GET"])
def train():
    return Response(train_model(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/save")
def save():
    return render_template("save.html")


@app.route("/recognize", methods=["POST", "GET"])
def recognizing():
    return Response(gen_frames(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/searching")
def searching():
    return render_template("search.html")


@app.route("/releasing")
def camrelease():
    global quit_flag
    quit_flag = True
    time.sleep(1)
    return "ok"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4412, debug=True, threaded=True)
